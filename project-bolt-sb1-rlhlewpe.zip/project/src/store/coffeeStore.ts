import { create } from 'zustand';
import { CoffeePreset, NavigationState } from '../types/coffee';
import { DEFAULT_PRESETS } from '../types/presets/defaultPresets';

interface CoffeeState {
  currentScreen: NavigationState;
  selectedOption: number;
  selectedPreset: CoffeePreset | null;
  DEFAULT_PRESETS: CoffeePreset[];
  whippedCream: boolean;
  setScreen: (screen: NavigationState) => void;
  setSelectedOption: (option: number) => void;
  setSelectedPreset: (preset: CoffeePreset | null) => void;
  setWhippedCream: (value: boolean) => void;
  cancelBrewing: () => void;
}

export const useCoffeeStore = create<CoffeeState>((set) => ({
  currentScreen: 'MAIN',
  selectedOption: 0,
  selectedPreset: null,
  whippedCream: false,
  DEFAULT_PRESETS,
  setScreen: (screen) => set({ currentScreen: screen }),
  setSelectedOption: (option) => set({ selectedOption: option }),
  setSelectedPreset: (preset) => set({ 
    selectedPreset: preset,
    whippedCream: preset?.whippedCream ?? false 
  }),
  setWhippedCream: (value) => set({ whippedCream: value }),
  cancelBrewing: () => set({ 
    currentScreen: 'MAIN',
    selectedPreset: null,
    whippedCream: false
  }),
}));