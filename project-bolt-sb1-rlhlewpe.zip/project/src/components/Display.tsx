import React from 'react';
import { Box } from '@mui/material';
import { ChevronUp, ChevronDown, Check, X } from 'lucide-react';
import { useCoffeeStore } from '../store/coffeeStore';
import { NavigationButton } from './navigation/NavigationButton';
import { DisplayContent } from './display/DisplayContent';
import { DisplayContainer } from './display/components/DisplayContainer';

export const Display: React.FC = () => {
  const {
    currentScreen,
    selectedOption,
    setSelectedOption,
    setScreen,
    setSelectedPreset,
    DEFAULT_PRESETS,
  } = useCoffeeStore();

  const handleUpClick = () => {
    setSelectedOption(Math.max(0, selectedOption - 1));
  };

  const handleDownClick = () => {
    setSelectedOption(Math.min(DEFAULT_PRESETS.length - 1, selectedOption + 1));
  };

  const handleConfirmClick = () => {
    if (currentScreen === 'MAIN') {
      setSelectedPreset(DEFAULT_PRESETS[selectedOption]);
      setScreen('WHIPPED_CREAM');
    } else if (currentScreen === 'WHIPPED_CREAM') {
      setScreen('BREWING');
    }
  };

  const handleCancelClick = () => {
    setScreen('MAIN');
    setSelectedOption(0);
    setSelectedPreset(null);
  };

  return (
    <Box className="relative" sx={{ width: 520, height: 400 }}>
      <DisplayContainer>
        <DisplayContent />
      </DisplayContainer>
      
      <Box className="absolute left-0 top-0 h-full flex flex-col justify-center space-y-4">
        <NavigationButton
          Icon={ChevronUp}
          onClick={handleUpClick}
          label="Up"
          disabled={selectedOption === 0 || currentScreen !== 'MAIN'}
        />
        <NavigationButton
          Icon={ChevronDown}
          onClick={handleDownClick}
          label="Down"
          disabled={selectedOption === DEFAULT_PRESETS.length - 1 || currentScreen !== 'MAIN'}
        />
      </Box>

      <Box className="absolute right-0 top-0 h-full flex flex-col justify-center space-y-4">
        <NavigationButton
          Icon={Check}
          onClick={handleConfirmClick}
          label="Confirm"
        />
        <NavigationButton
          Icon={X}
          onClick={handleCancelClick}
          label="Cancel"
        />
      </Box>
    </Box>
  );
};