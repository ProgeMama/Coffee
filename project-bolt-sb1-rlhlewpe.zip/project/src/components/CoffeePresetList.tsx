import React from 'react';
import { Box, Typography } from '@mui/material';
import { CoffeePreset } from '../types/coffee';

interface CoffeePresetListProps {
  presets: CoffeePreset[];
  selectedIndex: number;
}

const CoffeePresetList: React.FC<CoffeePresetListProps> = ({ presets, selectedIndex }) => {
  return (
    <Box className="space-y-4">
      <Typography variant="h6" className="text-center mb-4">
        Select Coffee
      </Typography>
      {presets.map((preset, index) => (
        <Box
          key={preset.id}
          className={`${
            selectedIndex === index ? 'bg-blue-100' : ''
          } p-4 rounded-lg transition-colors`}
        >
          <Typography variant="h6" className="text-center font-medium">
            {preset.name}
          </Typography>
          <Box className="flex justify-center space-x-4 mt-2 text-gray-600">
            <Typography variant="body2">
              {preset.beans} beans
            </Typography>
            <Typography variant="body2">
              {preset.amount}ml
            </Typography>
            <Typography variant="body2">
              {preset.milk}ml milk
            </Typography>
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default CoffeePresetList;