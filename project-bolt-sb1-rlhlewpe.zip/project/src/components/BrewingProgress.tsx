import React, { useEffect, useState } from 'react';
import { Box, Typography, LinearProgress } from '@mui/material';
import { Coffee } from 'lucide-react';
import { CoffeePreset } from '../types/coffee';
import { useCoffeeStore } from '../store/coffeeStore';

interface BrewingProgressProps {
  preset: CoffeePreset;
}

const BrewingProgress: React.FC<BrewingProgressProps> = ({ preset }) => {
  const { setScreen } = useCoffeeStore();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = preset.amount / 10; // 10ml = 1 second
    const interval = 100; // Update every 100ms
    const steps = (duration * 1000) / interval;
    const increment = 100 / steps;
    
    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = Math.min(100, prev + increment);
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(() => setScreen('MAIN'), 1000);
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [preset, setScreen]);

  return (
    <Box className="space-y-6 text-center">
      <Typography variant="h5" className="font-medium">
        Brewing {preset.name}
      </Typography>
      
      <Box className="flex justify-center">
        <Coffee size={48} className="text-blue-500 animate-pulse" />
      </Box>
      
      <Box className="space-y-2">
        <LinearProgress
          variant="determinate"
          value={progress}
          sx={{
            height: 10,
            borderRadius: 5,
            backgroundColor: '#E5E7EB',
            '& .MuiLinearProgress-bar': {
              backgroundColor: '#3B82F6',
            },
          }}
        />
        <Typography variant="body2" color="text.secondary">
          {Math.round(progress)}%
        </Typography>
      </Box>

      <Box className="grid grid-cols-3 gap-4 mt-4">
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            Beans
          </Typography>
          <Typography variant="h6">{preset.beans}</Typography>
        </Box>
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            Amount
          </Typography>
          <Typography variant="h6">{preset.amount}ml</Typography>
        </Box>
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            Milk
          </Typography>
          <Typography variant="h6">{preset.milk}ml</Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default BrewingProgress;