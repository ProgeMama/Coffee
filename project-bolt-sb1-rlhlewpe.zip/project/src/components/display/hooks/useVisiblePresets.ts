import { useMemo } from 'react';
import { CoffeePreset } from '../../../types/coffee';

const VISIBLE_ITEMS = 3;

export const useVisiblePresets = (presets: CoffeePreset[], selectedIndex: number) => {
  return useMemo(() => {
    let startIndex = selectedIndex - Math.floor(VISIBLE_ITEMS / 2);
    startIndex = Math.max(0, Math.min(startIndex, presets.length - VISIBLE_ITEMS));

    const visiblePresets = presets.slice(startIndex, startIndex + VISIBLE_ITEMS);
    const hasMoreAbove = startIndex > 0;
    const hasMoreBelow = startIndex + VISIBLE_ITEMS < presets.length;

    return {
      visiblePresets,
      hasMoreAbove,
      hasMoreBelow,
    };
  }, [presets, selectedIndex]);
};