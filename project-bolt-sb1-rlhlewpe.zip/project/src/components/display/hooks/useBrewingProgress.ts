import { useState, useEffect } from 'react';
import { CoffeePreset } from '../../../types/coffee';
import { useCoffeeStore } from '../../../store/coffeeStore';

const BREWING_DURATION = 15000; // 15 seconds total brewing time

export const useBrewingProgress = (preset: CoffeePreset) => {
  const { setScreen } = useCoffeeStore();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = 100; // Update every 100ms
    const steps = BREWING_DURATION / interval;
    const increment = 100 / steps;

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = Math.min(100, prev + increment);
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(() => setScreen('SUCCESS'), 500);
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [setScreen]);

  return { progress };
};