import React from 'react';
import { useCoffeeStore } from '../../store/coffeeStore';
import { CoffeePresetList } from './CoffeePresetList';
import { BrewingProgress } from './BrewingProgress';
import { SuccessScreen } from './SuccessScreen';
import { WhippedCreamOption } from './components/WhippedCreamOption';

export const DisplayContent: React.FC = () => {
  const { currentScreen, selectedOption, selectedPreset, DEFAULT_PRESETS } = useCoffeeStore();

  if (currentScreen === 'BREWING' && selectedPreset) {
    return <BrewingProgress preset={selectedPreset} />;
  }

  if (currentScreen === 'SUCCESS' && selectedPreset) {
    return <SuccessScreen preset={selectedPreset} />;
  }

  if (currentScreen === 'WHIPPED_CREAM') {
    return <WhippedCreamOption />;
  }

  return (
    <CoffeePresetList
      presets={DEFAULT_PRESETS}
      selectedIndex={selectedOption}
    />
  );
};