import React, { useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import { Check, Coffee, Wine } from 'lucide-react';
import { useCoffeeStore } from '../../store/coffeeStore';
import { CoffeePreset } from '../../types/coffee';
import { SuccessDetails } from './components/SuccessDetails';

interface SuccessScreenProps {
  preset: CoffeePreset;
}

export const SuccessScreen: React.FC<SuccessScreenProps> = ({ preset }) => {
  const { setScreen } = useCoffeeStore();

  useEffect(() => {
    const timer = setTimeout(() => {
      setScreen('MAIN');
    }, 3000);

    return () => clearTimeout(timer);
  }, [setScreen]);

  return (
    <Box className="flex flex-col items-center justify-center space-y-6 h-full">
      <Box className="relative">
        <Box className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-25" />
        <Box className="relative bg-green-500 rounded-full p-4">
          <Check size={48} className="text-white" />
        </Box>
      </Box>
      
      <Box className="text-center space-y-2">
        <Box className="flex items-center justify-center space-x-2">
          {preset.alcohol ? (
            <Wine size={24} className="text-red-500" />
          ) : (
            <Coffee size={24} className="text-blue-500" />
          )}
          <Typography variant="h5" className="font-medium text-green-600">
            Your {preset.name} is ready!
          </Typography>
        </Box>
        <Typography variant="body1" color="text.secondary">
          Enjoy your freshly brewed coffee
        </Typography>
      </Box>

      <SuccessDetails preset={preset} />
    </Box>
  );
};