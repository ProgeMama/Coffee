import React from 'react';
import { Box } from '@mui/material';
import { CoffeePreset } from '../../types/coffee';
import { PresetHeader } from './components/PresetHeader';
import { PresetDetails } from './components/PresetDetails';

interface PresetCardProps {
  preset: CoffeePreset;
  isSelected: boolean;
}

export const PresetCard: React.FC<PresetCardProps> = ({ preset, isSelected }) => {
  return (
    <Box
      className={`${
        isSelected ? 'bg-blue-100' : ''
      } p-4 rounded-lg transition-colors w-full`}
    >
      <PresetHeader preset={preset} />
      <PresetDetails preset={preset} />
    </Box>
  );
};