import React from 'react';
import { Box, Typography } from '@mui/material';
import { Coffee } from 'lucide-react';
import { CoffeePreset } from '../../types/coffee';
import { useBrewingProgress } from './hooks/useBrewingProgress';
import { ProgressIndicator } from './components/ProgressIndicator';
import { BrewingStats } from './components/BrewingStats';

interface BrewingProgressProps {
  preset: CoffeePreset;
}

export const BrewingProgress: React.FC<BrewingProgressProps> = ({ preset }) => {
  const { progress } = useBrewingProgress(preset);

  return (
    <Box className="space-y-6 text-center">
      <Typography variant="h5" className="font-medium">
        Brewing {preset.name}
      </Typography>
      
      <Box className="flex justify-center">
        <Coffee size={48} className="text-blue-500 animate-pulse" />
      </Box>
      
      <ProgressIndicator progress={progress} />
      
      <BrewingStats preset={preset} />
    </Box>
  );
};