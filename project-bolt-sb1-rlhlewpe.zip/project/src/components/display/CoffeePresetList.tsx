import React from 'react';
import { Box, Typography } from '@mui/material';
import { CoffeePreset } from '../../types/coffee';
import { PresetCard } from './PresetCard';
import { ScrollIndicator } from './components/ScrollIndicator';
import { useVisiblePresets } from './hooks/useVisiblePresets';

interface CoffeePresetListProps {
  presets: CoffeePreset[];
  selectedIndex: number;
}

export const CoffeePresetList: React.FC<CoffeePresetListProps> = ({ presets, selectedIndex }) => {
  const { visiblePresets, hasMoreAbove, hasMoreBelow } = useVisiblePresets(presets, selectedIndex);

  return (
    <Box className="relative h-full">
      <Typography variant="h6" className="text-center mb-4">
        Select Coffee
      </Typography>

      <ScrollIndicator show={hasMoreAbove} direction="up" />
      
      <Box className="space-y-4 overflow-hidden" sx={{ height: 280 }}>
        {visiblePresets.map((preset, index) => (
          <PresetCard
            key={preset.id}
            preset={preset}
            isSelected={selectedIndex === presets.indexOf(preset)}
          />
        ))}
      </Box>

      <ScrollIndicator show={hasMoreBelow} direction="down" />
    </Box>
  );
};