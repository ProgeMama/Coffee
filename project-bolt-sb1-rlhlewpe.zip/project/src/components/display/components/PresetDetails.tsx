import React from 'react';
import { Box, Typography } from '@mui/material';
import { CoffeePreset } from '../../../types/coffee';

interface PresetDetailsProps {
  preset: CoffeePreset;
}

export const PresetDetails: React.FC<PresetDetailsProps> = ({ preset }) => {
  return (
    <Box className="flex flex-wrap gap-2 mt-1">
      {preset.type === 'coffee' && (
        <Typography variant="body2" className="text-gray-600">
          {preset.beans} beans
        </Typography>
      )}
      <Typography variant="body2" className="text-gray-600">
        {preset.amount}ml {preset.type || 'coffee'}
      </Typography>
      {preset.milk > 0 && (
        <Typography variant="body2" className="text-gray-600">
          {preset.milk}ml milk
        </Typography>
      )}
      {preset.alcohol && (
        <Typography variant="body2" className="text-red-500">
          {preset.alcohol.amount}ml {preset.alcohol.type}
        </Typography>
      )}
      {preset.whippedCream && (
        <Typography variant="body2" className="text-blue-500">
          + whipped cream
        </Typography>
      )}
      {preset.flavoring && (
        <Typography variant="body2" className="text-pink-500">
          + {preset.flavoring.type} syrup
        </Typography>
      )}
    </Box>
  );
};