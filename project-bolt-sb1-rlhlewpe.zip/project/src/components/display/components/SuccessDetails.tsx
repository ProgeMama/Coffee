import React from 'react';
import { Box, Typography } from '@mui/material';
import { CoffeePreset } from '../../../types/coffee';
import { useCoffeeStore } from '../../../store/coffeeStore';

interface SuccessDetailsProps {
  preset: CoffeePreset;
}

export const SuccessDetails: React.FC<SuccessDetailsProps> = ({ preset }) => {
  const { whippedCream } = useCoffeeStore();

  return (
    <>
      <Box className="grid grid-cols-3 gap-6 mt-8">
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            Beans Used
          </Typography>
          <Typography variant="h6" className="text-green-600">
            {preset.beans}
          </Typography>
        </Box>
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            Coffee Amount
          </Typography>
          <Typography variant="h6" className="text-green-600">
            {preset.amount}ml
          </Typography>
        </Box>
        <Box className="text-center">
          <Typography variant="body2" color="text.secondary">
            {preset.alcohol ? preset.alcohol.type : 'Milk Added'}
          </Typography>
          <Typography variant="h6" className="text-green-600">
            {preset.alcohol ? preset.alcohol.amount : preset.milk}ml
          </Typography>
        </Box>
      </Box>

      {whippedCream && (
        <Typography variant="body1" className="text-green-600 font-medium">
          Topped with whipped cream ✨
        </Typography>
      )}
    </>
  );
};