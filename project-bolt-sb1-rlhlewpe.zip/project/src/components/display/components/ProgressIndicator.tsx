import React from 'react';
import { Box, Typography, LinearProgress } from '@mui/material';

interface ProgressIndicatorProps {
  progress: number;
}

export const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({ progress }) => {
  return (
    <Box className="space-y-2">
      <LinearProgress
        variant="determinate"
        value={progress}
        sx={{
          height: 10,
          borderRadius: 5,
          backgroundColor: '#E5E7EB',
          '& .MuiLinearProgress-bar': {
            backgroundColor: '#3B82F6',
          },
        }}
      />
      <Typography variant="body2" color="text.secondary">
        {Math.round(progress)}%
      </Typography>
    </Box>
  );
};