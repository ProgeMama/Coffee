import React from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import { Plus, Minus } from 'lucide-react';
import { BrewingStage } from '../../../types/coffee';
import { useCoffeeStore } from '../../../store/coffeeStore';

interface StageControlsProps {
  stage: BrewingStage;
}

export const StageControls: React.FC<StageControlsProps> = ({ stage }) => {
  const { adjustBeans, adjustMilk, currentBeans, currentMilk, selectedPreset } = useCoffeeStore();

  if (stage === 'COMPLETE') return null;

  const isBeansStage = stage === 'BEANS';
  const currentValue = isBeansStage 
    ? (currentBeans || selectedPreset?.beans || 0)
    : (currentMilk || selectedPreset?.milk || 0);
  const adjustFn = isBeansStage ? adjustBeans : adjustMilk;
  const step = isBeansStage ? 1 : 5;

  return (
    <Box className="flex items-center justify-center space-x-4">
      <IconButton 
        onClick={() => adjustFn(-step)}
        className="bg-gray-100 hover:bg-gray-200"
      >
        <Minus size={24} />
      </IconButton>
      
      <Typography variant="h6">
        {currentValue}{isBeansStage ? '' : 'ml'}
      </Typography>
      
      <IconButton 
        onClick={() => adjustFn(step)}
        className="bg-gray-100 hover:bg-gray-200"
      >
        <Plus size={24} />
      </IconButton>
    </Box>
  );
};