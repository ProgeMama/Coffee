import React from 'react';
import { Box, Typography } from '@mui/material';
import { Coffee, Wine, CandyCane } from 'lucide-react';
import { CoffeePreset } from '../../../types/coffee';

interface PresetHeaderProps {
  preset: CoffeePreset;
}

export const PresetHeader: React.FC<PresetHeaderProps> = ({ preset }) => {
  const iconSize = preset.id === 'espresso' ? 16 : 20;
  
  const getIcon = () => {
    if (preset.alcohol) {
      return <Wine size={iconSize} className="text-red-500 flex-shrink-0" />;
    }
    if (preset.type === 'cocoa') {
      return <CandyCane size={iconSize} className="text-pink-500 flex-shrink-0" />;
    }
    return (
      <Coffee 
        size={iconSize} 
        className={`flex-shrink-0 ${preset.id === 'espresso' ? 'text-amber-700' : ''}`} 
      />
    );
  };

  return (
    <Box className="flex items-center space-x-2 mb-2">
      {getIcon()}
      <Typography 
        variant="h6" 
        className={`font-medium text-gray-800 ${preset.id === 'espresso' ? 'text-sm' : ''}`}
        sx={{
          whiteSpace: 'normal',
          wordBreak: 'break-word',
          lineHeight: 1.2,
        }}
      >
        {preset.name}
      </Typography>
    </Box>
  );
};