import React from 'react';
import { Box } from '@mui/material';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface ScrollIndicatorProps {
  show: boolean;
  direction: 'up' | 'down';
}

export const ScrollIndicator: React.FC<ScrollIndicatorProps> = ({ show, direction }) => {
  if (!show) return null;

  const Icon = direction === 'up' ? ChevronUp : ChevronDown;
  const positionClass = direction === 'up' ? 'top-0' : 'bottom-0';

  return (
    <Box
      className={`absolute left-0 right-0 ${positionClass} pointer-events-none`}
      sx={{
        background: direction === 'up'
          ? 'linear-gradient(to top, transparent, white)'
          : 'linear-gradient(to bottom, transparent, white)',
        height: '40px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: direction === 'up' ? 'flex-start' : 'flex-end',
        padding: '8px',
      }}
    >
      <Icon size={20} className="text-gray-400 animate-bounce" />
    </Box>
  );
};