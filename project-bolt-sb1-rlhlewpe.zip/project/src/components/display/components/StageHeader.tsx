import React from 'react';
import { Box, Typography } from '@mui/material';
import { Coffee, Milk } from 'lucide-react';
import { BrewingStage } from '../../../types/coffee';

interface StageHeaderProps {
  stage: BrewingStage;
  beans: number;
  milk: number;
}

export const StageHeader: React.FC<StageHeaderProps> = ({ stage, beans, milk }) => {
  const getStageIcon = () => {
    if (stage === 'BEANS') {
      return <Coffee size={48} className="text-blue-500 animate-pulse" />;
    }
    return <Milk size={48} className="text-blue-500 animate-pulse" />;
  };

  const getStageText = () => {
    if (stage === 'BEANS') {
      return `Grinding beans (${beans})`;
    }
    return `Adding milk (${milk}ml)`;
  };

  return (
    <>
      <Typography variant="h5" className="font-medium">
        {getStageText()}
      </Typography>
      
      <Box className="flex justify-center">
        {getStageIcon()}
      </Box>
    </>
  );
};