import React from 'react';
import { Box } from '@mui/material';

interface DisplayContainerProps {
  children: React.ReactNode;
}

export const DisplayContainer: React.FC<DisplayContainerProps> = ({ children }) => {
  return (
    <Box
      className="absolute left-[60px] bg-white rounded-lg shadow-lg p-6 overflow-hidden"
      sx={{ width: 400, height: 400 }}
    >
      {children}
    </Box>
  );
};