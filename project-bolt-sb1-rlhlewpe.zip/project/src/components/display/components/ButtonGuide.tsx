import React from 'react';
import { Box, Typography } from '@mui/material';
import { ChevronUp, ChevronDown, Check, X } from 'lucide-react';
import { BrewingStage } from '../../../types/coffee';

interface ButtonGuideProps {
  stage: BrewingStage;
}

export const ButtonGuide: React.FC<ButtonGuideProps> = ({ stage }) => {
  if (stage === 'COMPLETE') return null;

  const isBeansStage = stage === 'BEANS';
  const unit = isBeansStage ? '' : 'ml';
  const step = isBeansStage ? '1' : '5';

  return (
    <Box className="grid grid-cols-2 gap-4">
      <Box className="space-y-4">
        {/* Left side buttons */}
        <Box className="flex items-center space-x-2 justify-end">
          <Typography variant="body2" color="text.secondary">
            +{step}{unit}
          </Typography>
          <Box className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
            <ChevronUp size={24} />
          </Box>
        </Box>
        <Box className="flex items-center space-x-2 justify-end">
          <Typography variant="body2" color="text.secondary">
            -{step}{unit}
          </Typography>
          <Box className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
            <ChevronDown size={24} />
          </Box>
        </Box>
      </Box>

      <Box className="space-y-4">
        {/* Right side buttons */}
        <Box className="flex items-center space-x-2">
          <Box className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center opacity-50">
            <Check size={24} />
          </Box>
          <Typography variant="body2" color="text.secondary">
            Wait...
          </Typography>
        </Box>
        <Box className="flex items-center space-x-2">
          <Box className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center opacity-50">
            <X size={24} />
          </Box>
          <Typography variant="body2" color="text.secondary">
            Cancel
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};