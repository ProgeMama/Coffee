import React from 'react';
import { Box, Typography } from '@mui/material';
import { CoffeePreset } from '../../../types/coffee';

interface BrewingStatsProps {
  preset: CoffeePreset;
}

export const BrewingStats: React.FC<BrewingStatsProps> = ({ preset }) => {
  return (
    <Box className="grid grid-cols-3 gap-4 mt-4">
      <Box className="text-center">
        <Typography variant="body2" color="text.secondary">
          Beans
        </Typography>
        <Typography variant="h6">{preset.beans}</Typography>
      </Box>
      <Box className="text-center">
        <Typography variant="body2" color="text.secondary">
          Amount
        </Typography>
        <Typography variant="h6">{preset.amount}ml</Typography>
      </Box>
      <Box className="text-center">
        <Typography variant="body2" color="text.secondary">
          Milk
        </Typography>
        <Typography variant="h6">{preset.milk}ml</Typography>
      </Box>
    </Box>
  );
};