import React from 'react';
import { Box, Typography, Switch } from '@mui/material';
import { Candy } from 'lucide-react';
import { useCoffeeStore } from '../../../store/coffeeStore';

export const WhippedCreamOption: React.FC = () => {
  const { whippedCream, setWhippedCream } = useCoffeeStore();

  return (
    <Box className="flex flex-col items-center space-y-4">
      <Typography variant="h5" className="font-medium">
        Add Whipped Cream?
      </Typography>
      
      <Box className="flex justify-center">
        <Candy size={48} className="text-blue-500" />
      </Box>
      
      <Box className="flex items-center space-x-4">
        <Typography>No</Typography>
        <Switch
          checked={whippedCream}
          onChange={(e) => setWhippedCream(e.target.checked)}
          color="primary"
        />
        <Typography>Yes</Typography>
      </Box>
      
      <Typography variant="body2" color="text.secondary" className="text-center">
        {whippedCream ? 'Your coffee will be topped with whipped cream' : 'No whipped cream will be added'}
      </Typography>
    </Box>
  );
};