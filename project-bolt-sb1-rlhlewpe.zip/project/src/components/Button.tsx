import React from 'react';
import { IconButton } from '@mui/material';
import { LucideIcon } from 'lucide-react';

interface ButtonProps {
  Icon: LucideIcon;
  onClick: () => void;
  position: 'top-left' | 'bottom-left' | 'top-right' | 'bottom-right';
}

const positionStyles = {
  'top-left': 'left-[-60px] top-[100px]',
  'bottom-left': 'left-[-60px] top-[200px]',
  'top-right': 'right-[-60px] top-[100px]',
  'bottom-right': 'right-[-60px] top-[200px]',
};

const Button: React.FC<ButtonProps> = ({ Icon, onClick, position }) => {
  return (
    <IconButton
      onClick={onClick}
      className={`absolute ${positionStyles[position]} bg-gray-200 hover:bg-gray-300`}
      sx={{ width: 48, height: 48 }}
    >
      <Icon size={24} />
    </IconButton>
  );
};

export default Button;