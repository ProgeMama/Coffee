import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { LucideIcon } from 'lucide-react';

interface NavigationButtonProps {
  Icon: LucideIcon;
  onClick: () => void;
  label: string;
  disabled?: boolean;
}

export const NavigationButton: React.FC<NavigationButtonProps> = ({
  Icon,
  onClick,
  label,
  disabled = false,
}) => {
  return (
    <Tooltip title={label} placement="right">
      <span>
        <IconButton
          onClick={onClick}
          disabled={disabled}
          className={`${
            disabled ? 'bg-gray-100' : 'bg-gray-200 hover:bg-gray-300'
          }`}
          sx={{
            width: 48,
            height: 48,
            opacity: disabled ? 0.5 : 1,
          }}
        >
          <Icon size={24} />
        </IconButton>
      </span>
    </Tooltip>
  );
};