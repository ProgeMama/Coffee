import { CoffeePreset } from '../coffee';

export const DEFAULT_PRESETS: CoffeePreset[] = [
  { 
    id: 'espresso', 
    name: 'Espresso', 
    beans: 2, 
    amount: 30, 
    milk: 0, 
    whippedCream: false,
    type: 'coffee'
  },
  { 
    id: 'peppermint-cocoa',
    name: 'Peppermint Cocoa',
    beans: 0,
    amount: 240,
    milk: 200,
    whippedCream: true,
    type: 'cocoa',
    flavoring: {
      type: 'peppermint',
      amount: 15
    }
  },
  { 
    id: 'latte', 
    name: 'Latte', 
    beans: 3, 
    amount: 150, 
    milk: 60, 
    whippedCream: false,
    type: 'coffee'
  },
  { 
    id: 'cappuccino', 
    name: 'Cappuccino', 
    beans: 4, 
    amount: 150, 
    milk: 30, 
    whippedCream: false,
    type: 'coffee'
  },
  { 
    id: 'black', 
    name: 'Black Coffee', 
    beans: 3, 
    amount: 150, 
    milk: 0, 
    whippedCream: false,
    type: 'coffee'
  },
  { 
    id: 'irish-whiskey', 
    name: 'Irish Coffee (Whiskey)', 
    beans: 4, 
    amount: 150, 
    milk: 30, 
    whippedCream: true,
    type: 'coffee',
    alcohol: {
      type: 'whiskey',
      amount: 44
    }
  },
  { 
    id: 'irish-baileys', 
    name: 'Irish Coffee (Baileys)', 
    beans: 4, 
    amount: 150, 
    milk: 0, 
    whippedCream: true,
    type: 'coffee',
    alcohol: {
      type: 'baileys',
      amount: 50
    }
  }
];