export interface CoffeePreset {
  id: string;
  name: string;
  beans: number;
  amount: number;
  milk: number;
  whippedCream?: boolean;
  alcohol?: {
    type: 'whiskey' | 'baileys';
    amount: number;
  };
  type?: 'coffee' | 'cocoa';
  flavoring?: {
    type: 'peppermint' | 'vanilla' | 'caramel';
    amount: number;
  };
}

export type NavigationState = 'MAIN' | 'WHIPPED_CREAM' | 'BREWING' | 'SUCCESS';
export type BrewingStage = 'BEANS' | 'MILK' | 'WHIPPED_CREAM' | 'COMPLETE';